#include <shard/syntax/nodes/Types/DelegateTypeSyntax.h>

#include <string>

using namespace shard;

std::wstring DelegateTypeSyntax::ToString()
{
    return std::wstring();
}
