#pragma once
#include <shard/ShardScriptAPI.h>

namespace shard
{
	enum class TokenType
	{
		// Generic
		Unknown,
		EndOfFile,   // End of file
		Trivia,      // any non-visible
		NewKeyword,  // new keyword
		Identifier,	 // member name

		// Generic operators
		AssignOperator,     // =
		LambdaOperator,		// =>

		// Binary arithmetic operators
		AddOperator,		  // +
		SubOperator,		  // -
		MultOperator,		  // *
		DivOperator,		  // /
		ModOperator,		  // %
		PowOperator,	      // ^

		// Assigning binary arithmetic operator
		AddAssignOperator,    // +=
		SubAssignOperator,    // -=
		MultAssignOperator,   // *=
		DivAssignOperator,    // /=
		ModAssignOperator,    // %=
		PowAssignOperator,    // ^=

		// Unary arithmetic operators
		IncrementOperator,   // ++
		DecrementOperator,   // --

		// Binary bitwise operators
		OrOperator,				// |
		AndOperator,			// &
		RightShiftOperator,		// >>
		LeftShiftOperator,		// <<

		// Assigning binary bitwise operators
		OrAssignOperator,			// |=
		AndAssignOperator,			// &=
		//RightShiftAssignOperator,	// >>=
		//LeftShiftAssignOperator,	// <<=

		// Binary boolean-returning operators
		EqualsOperator,		     // ==
		NotEqualsOperator,	     // !=
		GreaterOperator,		 // >
		GreaterOrEqualsOperator, // >=
		LessOperator,		     // <
		LessOrEqualsOperator,    // <=

		// Unary boolean operators
		NotOperator,         // !

		// Literals
		NullLiteral,          // 'null'
		CharLiteral,		  // single character in ''
		StringLiteral,		  // string in ""
		BooleanLiteral,		  // 'true' or 'false'
		NumberLiteral,	      // number value
		DoubleLiteral,		  // floating point number value
		NativeLiteral,		  // architectures' native number

		// Punctuation
		Colon,				  // :
		Semicolon,			  // ;
		OpenBrace,			  // {
		CloseBrace,  		  // }
		OpenCurl,			  // (
		CloseCurl,			  // )
		OpenSquare,			  // [
		CloseSquare,		  // ]
		Delimeter,			  // .
		Comma,				  // ,
		Question,			  // ?

		// Member modifier keywords
		PublicKeyword,		  // public
		PrivateKeyword,		  // private
		ProtectedKeyword,	  // protected
		InternalKeyword,	  // internal
		StaticKeyword,		  // static
		AbstractKeyword,	  // abstract
		SealedKeyword,		  // sealed
		PartialKeyword,		  // partial
		OverrideKeyword,	  // override
		VirtualKeyword,		  // virtual
		ExternKeyword,		  // extern
		
		// Property accessor keywords
		GetKeyword,			  // get
		SetKeyword,			  // set
		FieldKeyword,		  // field
		IndexerKeyword,		  // indexer

		// Built-in type keywords
		VoidKeyword,		  // void
		VarKeyword,			  // var
		IntegerKeyword,		  // int
		DoubleKeyword,		  // double
		ShortKeyword,		  // short
		LongKeyword,		  // long
		CharKeyword,		  // char
		StringKeyword,		  // string
		BooleanKeyword,		  // bool
		DelegateKeyword,	  // delegate
		LambdaKeyword,		  // lambda

		// Directive declaration keywords
		UsingKeyword,		  // using
		FromKeyword,		  // from
		ImportKeyword,		  // import

		// Type declaration keywords
		MethodKeyword,		  // method
		ClassKeyword,		  // class
		StructKeyword,		  // struct
		InterfaceKeyword,	  // interface
		NamespaceKeyword,	  // namespace

		// Loops keywords
		ForKeyword,			// for
		WhileKeyword,		// while
		UntilKeyword,		// until
		DoKeyword,			// do
		ForeachKeyword,		// foreach

		// Conditional clause keywords
		IfKeyword,		 // if
		UnlessKeyword,	 // unless
		ElseKeyword,	 // else

		// Functional keywords
		ReturnKeyword,		  // return
		ThrowKeyword,		  // throw
		BreakKeyword,		  // break
		ContinueKeyword,	  // continue
		GotoKeyword,		  // goto
	};
}