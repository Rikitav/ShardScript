#pragma once
#include <shard/ShardScriptAPI.h>

namespace shard
{
	enum class SymbolAccesibility
	{
		Private,
		Public,
		Protected
	};
}
