#pragma once
#include <shard/ShardScriptAPI.h>

#include <shard/syntax/symbols/TypeSymbol.h>
#include <shard/syntax/symbols/FieldSymbol.h>

#include <stack>
#include <string>

namespace shard
{
	class SHARD_API ObjectInstance
	{
	public:
		const long Id;
		const shard::TypeSymbol* Info;
		const bool IsNullable = false;

		bool IsFieldInstance = false;
		size_t ReferencesCounter;
		void* Ptr;

		inline ObjectInstance(const long id, const shard::TypeSymbol* info, void* ptr)
			: Id(id), Info(info), Ptr(ptr), ReferencesCounter(0) { }
		
		inline ~ObjectInstance() = default;

		static ObjectInstance* FromValue(long value);
		static ObjectInstance* FromValue(double value);
		static ObjectInstance* FromValue(bool value);
		static ObjectInstance* FromValue(wchar_t value);
		static ObjectInstance* FromValue(const wchar_t* value);
		static ObjectInstance* FromValue(const std::wstring& value);

		ObjectInstance* GetField(shard::FieldSymbol* field);
		void SetField(shard::FieldSymbol* field, ObjectInstance* instance);

		ObjectInstance* GetElement(size_t index);
		void SetElement(size_t index, ObjectInstance* instance);
		bool IsInBounds(size_t index);

		void IncrementReference();
		void DecrementReference();

		/*
		template<typename T>
		inline void WritePrimitive(T& value)
		{
			void* ptr = &value;
			WriteMemory(0, Info->MemoryBytesSize, ptr);
		}

		template<typename T>
		inline T ReadPrimitive()
		{
			return *reinterpret_cast<T*>(Ptr);
		}
		*/

		void WriteBoolean(const bool& value);
		void WriteInteger(const long& value);
		void WriteDouble(const double& value);
		void WriteCharacter(const wchar_t& value);
		void WriteString(const std::wstring& value);

		bool AsBoolean();
		long AsInteger();
		double AsDouble();
		wchar_t AsCharacter();
		std::wstring& AsString();

		void* OffsetMemory(const size_t offset, const size_t size) const;
		void ReadMemory(const size_t offset, const size_t size, void* dst) const;
		void WriteMemory(const size_t offset, const size_t size, const void* src) const;
	};
}
