#pragma once
/*
#include <shard/syntax/SyntaxNode.h>
#include <shard/syntax/SyntaxToken.h>

#include <shard/parsing/structures/Object.h>
#include <shard/parsing/structures/ObjectsTree.h>

#include <shard/syntax/nodes/ExpressionSyntax.h>
#include "syntax/nodes/IndexatorListSyntax.h"

#include <shard/syntax/nodes/MemberDeclarations/ClassDeclarationSyntax.h>
#include <shard/syntax/nodes/MemberDeclarations/MethodDeclarationSyntax.h>
#include <shard/syntax/nodes/MemberDeclarations/StructDeclarationSyntax.h>

#include <vector>

typedef std::vector<shard::SyntaxToken> SyntaxTokenList;

typedef shard::SyntaxNode* pSyntaxNode;

typedef shard::ClassDeclarationSyntax* pClassDeclaration;
typedef shard::StructDeclarationSyntax* pStructDeclaration;
typedef shard::MethodDeclarationSyntax* pMethodDeclaration;

typedef shard::ExpressionSyntax* pExpression;
typedef shard::* pLinkedExpression;
typedef shard::LinkedExpressionSyntax* pLinkedExpression;
typedef shard::LinkedExpressionNode* pLinkedExpressionNode;

typedef shard::IndexatorListSyntax* pIndexatorList;

typedef shard::Object* POBJECT;
*/
